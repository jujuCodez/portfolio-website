import React from 'react';

const ArticleContent = () => {
  return (
    <div>
      <p>This is the content of Article 5, which is implemented using React JS.</p>
      <p>React is a JavaScript library for building user interfaces.</p>
      <p>It makes creating interactive UIs simple and intuitive.</p>
    </div>
  );
};

export default ArticleContent;
