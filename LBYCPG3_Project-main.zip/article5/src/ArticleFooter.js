import React from 'react';

const ArticleFooter = () => {
  return (
    <footer>
      <p>© 2023 Juju's Consortium of Stuff. All rights reserved.</p>
    </footer>
  );
};

export default ArticleFooter;
