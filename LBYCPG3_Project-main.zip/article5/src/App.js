import React from 'react';
import Article5 from './Article5';
import './App.css';

function App() {
  return (
    <div className="App">
      <Article5 />
    </div>
  );
}

export default App;